/** Execution mode and resource limits for the Node PTC provider. */
import z from '@deepseek-ai/schemastery';
import type { LaunchConfig } from './launch.ts';
/** Deployment-varying runtime bounds and launch choices. */
export interface Config {
    /** Worker invocation in the subprocess world; omitted selects the local carrier. */
    launch?: LaunchConfig;
    /** per-call starts fresh processes; persistent-in-memory retains a REPL per owner under the same file policy. */
    executionMode?: 'per-call' | 'persistent-in-memory';
    /** Default elapsed deadline, including nested tool and approval waits. */
    timeoutMs?: number;
    /** Maximum numeric elapsed budget accepted by resolve. */
    maxTimeoutMs?: number;
    /** Combined serialized logs, completion and diagnostic byte cap. */
    maxOutputBytes?: number;
    /** V8 old-generation heap limit in MiB; native allocations are excluded. */
    maxOldGenerationSizeMb?: number;
    /** Maximum control frame, outstanding argument and queued control-output bytes. */
    maxMessageBytes?: number;
    /** Maximum simultaneous host binding calls accepted from a program. */
    maxPendingCalls?: number;
    /** Managed process termination and output-drain grace in milliseconds. */
    graceMs?: number;
}
/** Configuration after Loader defaults and executable selection. */
export type ResolvedConfig = Required<Config>;
/** Loader defaults for the Node PTC provider. */
export declare const NodeConfig: z<Config>;
/**
 * Validate resolved Node limits and paths.
 * @param config - Loader-defaulted fields with the selected executable.
 */
export declare function validateConfig(config: ResolvedConfig): void;
//# sourceMappingURL=config.d.ts.map