from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from typing import Any

from connector.logging import logger
from connector.runtime_protocol import (
    RuntimeSessionStateCache,
    RuntimeTimelineItem,
    SessionNotice,
)
from connector.runtime_protocol.host import RuntimeHostClient
from connector.runtimes.codex.domain import sessions as codex_sessions
from connector.runtimes.codex.domain.approvals import approval_notice_from_request
from connector.runtimes.codex.domain.async_inputs import AsyncInputSubmissions
from connector.runtimes.codex.domain.input_requests import (
    CodexAsyncInputCall,
    async_input_notice_id,
    async_user_input_notice,
    codex_async_input_call,
    codex_input_request,
    user_input_notice,
)
from connector.runtimes.codex.domain.notices import CodexNoticeRegistry


@dataclass(slots=True)
class CodexNoticeHandler:
    host: RuntimeHostClient
    session_states: RuntimeSessionStateCache
    active_turn_ids: dict[str, str]
    notices: CodexNoticeRegistry
    async_submissions: AsyncInputSubmissions | None = None

    async def sync_async_input_items(
        self,
        session_id: str,
        thread_id: str,
        items: tuple[RuntimeTimelineItem, ...],
        *,
        transport: str | None = None,
    ) -> None:
        """Rebuild async questionnaire notices from live or replayed Timeline items."""

        calls: list[tuple[CodexAsyncInputCall, RuntimeTimelineItem]] = []
        answered_call_ids: set[str] = set()
        for item in items:
            raw = item.metadata.get("raw")
            if not isinstance(raw, Mapping):
                continue
            call = codex_async_input_call(raw)
            if call is not None:
                calls.append((call, item))
            reply_call_ids = raw.get("_asyncInputReplyCallIds")
            if isinstance(reply_call_ids, list):
                answered_call_ids.update(
                    call_id
                    for call_id in reply_call_ids
                    if isinstance(call_id, str) and call_id
                )

        for call_id in answered_call_ids:
            if self.async_submissions is not None:
                self.async_submissions.record(call_id, "answered")
            notice_id = async_input_notice_id(call_id)
            existing = self.notices.get(notice_id)
            if existing is None or existing.status not in {"open", "responding"}:
                continue
            resolved = self.notices.transition(
                notice_id,
                status="resolved",
                response_required=False,
                blocking=None,
                actions=(),
                context={"inputStatus": "resolved", "decision": "answered"},
                metadata={"source": "codex.async_input/replayed_answer"},
            )
            if resolved is not None:
                await self.host.notice_upsert(resolved)

        for call, item in calls:
            existing = self.notices.get(call.notice_id)
            submitted = (
                self.async_submissions.status(call.call_id)
                if self.async_submissions is not None
                else None
            )
            resolved = (
                call.call_id in answered_call_ids
                or (
                    existing is not None
                    and existing.status
                    in {"closed", "resolved", "cancelled", "expired"}
                )
                or submitted in {"answered", "cancelled"}
            )
            notice = async_user_input_notice(
                session_id=session_id,
                thread_id=thread_id,
                turn_id=item.turn_id,
                item_id=item.id,
                call=call,
                resolved=resolved,
            )
            if transport is not None:
                notice = replace(
                    notice,
                    metadata={**dict(notice.metadata), "transport": transport},
                )
            if existing is None or existing.session_id != session_id:
                self.notices.upsert(notice)
                await self.host.notice_upsert(notice)
            elif resolved and existing.status in {"open", "responding"}:
                resolved_notice = self.notices.transition(
                    existing.notice_id,
                    status="resolved",
                    response_required=False,
                    blocking=None,
                    actions=(),
                    context={"inputStatus": "resolved", "decision": "answered"},
                    metadata={"source": "codex.async_input/replayed_answer"},
                )
                if resolved_notice is not None:
                    await self.host.notice_upsert(resolved_notice)

    async def handle_approval_request(
        self,
        session_id: str,
        thread_id: str,
        method: str,
        params: dict[str, Any],
        request_id: Any,
    ) -> None:
        """Publish an approval notice and waiting-approval session state.

        Side effects:
        - binds the active turn id when the approval event carries one
        - upserts a SessionNotice through the host
        - updates SessionState.status to waiting_approval
        """

        turn_id = codex_sessions.turn_id_from_result(
            params
        ) or self.active_turn_ids.get(session_id)
        if turn_id is not None:
            self.active_turn_ids[session_id] = turn_id
        notice = approval_notice_from_request(
            session_id=session_id,
            thread_id=thread_id,
            method=method,
            params=params,
            request_id=request_id,
            turn_id=turn_id,
        )
        self.notices.upsert(notice)
        logger.info(
            "codex approval notice upsert method={} session_id={} thread_id={} turn_id={} notice_id={} request_id={} action_ids={}",
            method,
            session_id,
            thread_id,
            turn_id,
            notice.notice_id,
            request_id,
            [action.get("actionId") for action in notice.actions],
        )
        await self.host.notice_upsert(notice)
        await self.session_states.update(
            session_id=session_id,
            external_session_id=thread_id,
            status="waiting_approval",
            metadata={
                "source": method,
                "notice_id": notice.notice_id,
                **({"turn_id": turn_id} if turn_id else {}),
            },
        )

    async def handle_user_input_request(
        self,
        session_id: str,
        thread_id: str,
        method: str,
        params: dict[str, Any],
        request_id: Any,
    ) -> None:
        """Publish a `request_user_input` questionnaire for the platform form.

        Side effects:
        - binds the active turn id when the request carries one
        - upserts a SessionNotice through the host
        - updates SessionState.status to waiting for blocking requests

        Invalid questionnaires raise, so the server request is answered with an
        error instead of leaving the app-server waiting forever.
        """

        request = codex_input_request(params)
        turn_id = _first_string(
            params, "turnId", "turn_id"
        ) or self.active_turn_ids.get(session_id)
        if turn_id is not None:
            self.active_turn_ids[session_id] = turn_id
        is_blocking = params.get("isBlocking", True) is not False
        notice = user_input_notice(
            session_id=session_id,
            thread_id=thread_id,
            turn_id=turn_id,
            item_id=_first_string(params, "itemId", "item_id"),
            request_id=str(request_id),
            request=request,
            is_blocking=is_blocking,
        )
        self.notices.upsert(notice)
        logger.info(
            "codex input request notice upsert method={} session_id={} thread_id={} turn_id={} notice_id={} request_id={} question_count={} is_blocking={}",
            method,
            session_id,
            thread_id,
            turn_id,
            notice.notice_id,
            request_id,
            len(request.form.questions),
            is_blocking,
        )
        await self.host.notice_upsert(notice)
        if not is_blocking:
            return
        await self.session_states.update(
            session_id=session_id,
            external_session_id=thread_id,
            status="waiting",
            metadata={
                "source": method,
                "notice_id": notice.notice_id,
                **({"turn_id": turn_id} if turn_id else {}),
            },
        )

    async def close_blocking_notices_for_terminal_turn(
        self,
        session_id: str,
        status: str,
        reason: str,
        source: str,
    ) -> None:
        """Close open blocking notices and questionnaires for a terminal turn.

        Side effects:
        - mutates the Codex notice registry
        - publishes each closed notice through the host
        """

        for notice in self.notices.close_open_for_session(
            session_id=session_id,
            status=status,
            reason=reason,
            source=source,
        ):
            await self.host.notice_upsert(notice)

    async def close_execution_errors_for_started_turn(self, session_id: str) -> None:
        """Dismiss stale failed-turn cards once a new turn starts."""

        for notice in self.notices.close_execution_errors_for_session(
            session_id=session_id,
            status="closed",
            reason="turn_started",
            source="codex.turn/started",
        ):
            await self.host.notice_upsert(notice)

    def execution_error_notice(
        self,
        session_id: str,
        thread_id: str,
        turn_id: str | None,
        params: dict[str, Any],
    ) -> SessionNotice:
        error = error_from_params(params)
        code = str(error.get("code") or "codex_turn_failed")
        message = str(error.get("message") or "Codex turn failed.")
        notice_component = turn_id or code
        return SessionNotice(
            notice_id=f"notice_error_{session_id}_{notice_component}",
            session_id=session_id,
            runtime="codex",
            type="interaction",
            title="Codex turn failed",
            message=message,
            severity="error",
            status="open",
            interaction_type="execution_error",
            # The turn is already over. A session-blocking notice with no
            # actions would disable sending with no way to resolve it, so the
            # error stays visible without locking the composer.
            blocking=None,
            response_required=False,
            actions=(),
            source={
                "threadId": thread_id,
                **({"turnId": turn_id} if turn_id else {}),
            },
            context={
                "kind": "execution_error",
                "error": error,
                **({"turnId": turn_id} if turn_id else {}),
            },
            metadata={"source": "codex.turn/failed"},
        )

    async def publish_execution_error_notice(self, notice: SessionNotice) -> None:
        """Publish a failed-turn execution notice.

        Side effects:
        - mutates the Codex notice registry
        - upserts the notice through the host
        """

        self.notices.upsert(notice)
        await self.host.notice_upsert(notice)


def _first_string(mapping: Mapping[str, Any], *keys: str) -> str | None:
    for key in keys:
        value = mapping.get(key)
        if isinstance(value, str) and value:
            return value
    return None


def error_from_params(params: dict[str, Any]) -> dict[str, Any]:
    raw = params.get("error")
    if not isinstance(raw, dict):
        turn = params.get("turn")
        if isinstance(turn, dict):
            raw = turn.get("error")
    if isinstance(raw, dict):
        code = raw.get("code")
        message = raw.get("message") or raw.get("detail")
        return {
            "code": str(code or "codex_turn_failed"),
            "message": str(message or "Codex turn failed."),
            "raw": raw,
        }
    message = params.get("message") or params.get("reason")
    return {
        "code": "codex_turn_failed",
        "message": str(message or "Codex turn failed."),
    }
