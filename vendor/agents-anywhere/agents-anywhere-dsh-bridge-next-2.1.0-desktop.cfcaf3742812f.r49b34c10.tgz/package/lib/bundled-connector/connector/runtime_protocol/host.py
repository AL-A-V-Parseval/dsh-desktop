from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Mapping
from typing import Any
from connector.core.json_kv import JsonKeyValueStore

from connector.runtime_protocol.models import (
    RuntimeAttachmentContent,
    RuntimeCapabilitySet,
    RuntimeModelCatalog,
    RuntimePermissionCatalog,
    RuntimeStatus,
    RuntimeTimelineItem,
    SessionNotice,
    SessionSourceObservation,
)


class RuntimeHostClient(ABC):
    """Runtime -> Connector."""

    async def prepare_runtime_host(self, runtime_id: str) -> RuntimeHostClient:
        """Bind storage before a provider constructs its runtime; legacy hosts are unchanged."""
        return self

    @property
    def runtime_kv(self) -> JsonKeyValueStore:
        return JsonKeyValueStore.default()

    async def publish_runtime_notifications(
        self, runtime: str, notifications: list[dict[str, Any]], runtime_id: str | None = None
    ) -> None:
        """Await the existing Connector ingest path, without the fallback queue."""
        raise NotImplementedError("Synchronous notification ingestion is unavailable")

    @property
    @abstractmethod
    def connector_id(self) -> str:
        raise NotImplementedError

    @property
    def session_namespace(self) -> str:
        """Stable namespace used when deriving platform session identities."""

        return self.connector_id

    async def session_meta_upsert(
        self,
        session_id: str,
        runtime: str,
        external_session_id: str | None = None,
        title: str | None = None,
        cwd: str | None = None,
        ordering_time: str | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> None:
        raise NotImplementedError

    async def session_state_update(
        self,
        session_id: str,
        runtime: str,
        status: RuntimeStatus | None = None,
        selections: Mapping[str, str | None] | None = None,
        external_session_id: str | None = None,
        status_reason: str | None = None,
        error: Mapping[str, Any] | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> None:
        raise NotImplementedError

    async def session_source_update(
        self,
        observation: SessionSourceObservation,
    ) -> None:
        raise NotImplementedError

    async def session_turn_ended(
        self,
        session_id: str,
        runtime: str,
        external_session_id: str | None = None,
        turn_id: str | None = None,
        outcome: str = "completed",
        metadata: Mapping[str, Any] | None = None,
    ) -> None:
        raise NotImplementedError

    async def runtime_capabilities_update(
        self,
        capabilities: RuntimeCapabilitySet,
    ) -> None:
        raise NotImplementedError

    async def session_capabilities_update(
        self,
        capabilities: RuntimeCapabilitySet,
    ) -> None:
        raise NotImplementedError

    async def model_catalog_update(
        self,
        catalog: RuntimeModelCatalog,
    ) -> None:
        raise NotImplementedError

    async def permission_catalog_update(
        self,
        catalog: RuntimePermissionCatalog,
    ) -> None:
        raise NotImplementedError

    async def timeline_sync(
        self,
        session_id: str,
        runtime: str,
        items: tuple[RuntimeTimelineItem, ...],
        external_session_id: str | None = None,
        complete: bool = False,
        metadata: Mapping[str, Any] | None = None,
    ) -> None:
        raise NotImplementedError

    async def timeline_item_upsert(
        self,
        item: RuntimeTimelineItem,
    ) -> None:
        raise NotImplementedError

    async def notice_upsert(
        self,
        notice: SessionNotice,
    ) -> None:
        raise NotImplementedError

    async def runtime_error(
        self,
        runtime: str,
        code: str,
        message: str,
        session_id: str | None = None,
        external_session_id: str | None = None,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        raise NotImplementedError

    async def runtime_health_update(
        self,
        status: str,
        error: Mapping[str, Any] | None = None,
        phase: Mapping[str, Any] | None = None,
    ) -> None:
        """Report a provider-owned health change for this runtime instance.

        ``phase`` names a step inside a non-error status (for example
        ``{"code": "syncing", "message": ...}`` while ``starting``); it is
        shown to the user as progress, never as a fault. The Connector routes
        this to the owning supervisor so runtime status stays one state
        machine. Hosts that are not bound to an instance ignore it.
        """

        return None

    async def attachment_download(
        self,
        session_id: str,
        file_id: str,
    ) -> RuntimeAttachmentContent:
        raise NotImplementedError

    async def sync_state_read(
        self,
        key: str,
    ) -> Mapping[str, Any] | None:
        raise NotImplementedError

    async def sync_state_write(
        self,
        key: str,
        value: Mapping[str, Any],
    ) -> None:
        raise NotImplementedError

    async def sync_state_delete(
        self,
        key: str,
    ) -> None:
        raise NotImplementedError


def runtime_kv_store(host: RuntimeHostClient) -> JsonKeyValueStore:
    """Support older structural Host implementations outside the Connector."""
    store = getattr(host, "runtime_kv", None)
    return store if store is not None else JsonKeyValueStore.default()
